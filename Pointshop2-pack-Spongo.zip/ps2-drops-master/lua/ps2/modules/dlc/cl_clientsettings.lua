Pointshop2.ClientSettings.SettingsTable.BasicSettings['NoUnbox'] =  {
    tooltip = "Check this to skip the unboxing animation when opening crates",
    label = "Disable unboxing animation", 
    value = false
}