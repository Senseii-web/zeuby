# Creating an issue

The issue tracker is for bugs or feature requests. Try to avoid posting issues like "How do I do X?"

# Pull requests

Don't use glua's C syntax
