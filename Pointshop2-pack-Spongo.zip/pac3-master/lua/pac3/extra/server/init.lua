pacx = pacx or {}

include("pac3/extra/shared/init.lua")

include("contraption.lua")
include("map_outfit.lua")