LibK.SQL = {}
--SQL Configuration
LibK.SQL.UseMysql = false --Set to true to use MSQL, false will use SQLite(sv.db)
--MySQL Settings
LibK.SQL.Host = "127.0.0.1"
LibK.SQL.Port = 3306
LibK.SQL.User = "root"
LibK.SQL.Password = ""
LibK.SQL.Database = "dbname"
