GLib.Lua.TableKeyValueType = GLib.Enum (
	{
		Nil     = 0,
		False   = 1,
		True    = 2,
		Integer = 3,
		Double  = 4,
		String  = 5
	}
)