GLib.Net.Layer2.SplitPacketType = GLib.Enum (
	{
		Start        = 1,
		Continuation = 2
	}
)