GLib.Net.ConnectionClosureReason = GLib.Enum (
	{
		LocalClosure  =  1,
		RemoteClosure =  2,
		Timeout       =  4,
		CarrierLost   =  8,
		TheApocalypse = 16
	}
)