local self = {}
GLib.Net.Layer3.Channel = GLib.MakeConstructor (self, GLib.Net.IChannel)