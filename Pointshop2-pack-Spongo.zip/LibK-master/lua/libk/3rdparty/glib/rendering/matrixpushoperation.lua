GLib.Rendering.MatrixPushOperation = GLib.Enum (
	{
		Override     = 1,
		PreMultiply  = 2,
		PostMultiply = 3
	}
)