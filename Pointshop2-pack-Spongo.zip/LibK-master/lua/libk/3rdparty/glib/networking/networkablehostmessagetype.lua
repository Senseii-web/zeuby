GLib.Networking.NetworkableHostMessageType = GLib.Enum (
	{
		NetworkableDestroyed = 0x01,
		Custom               = 0xFF
	}
)